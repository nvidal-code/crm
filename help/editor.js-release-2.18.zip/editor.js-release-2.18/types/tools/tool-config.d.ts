/**
 * Tool configuration object. Specified by Tool developer, so leave it as object
 */
export type ToolConfig = object;
